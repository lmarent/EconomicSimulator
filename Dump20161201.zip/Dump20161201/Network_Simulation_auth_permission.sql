-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: Network_Simulation
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_37ef4eb4` (`content_type_id`),
  CONSTRAINT `content_type_id_refs_id_d043b34a` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can add permission',2,'add_permission'),(5,'Can change permission',2,'change_permission'),(6,'Can delete permission',2,'delete_permission'),(7,'Can add group',3,'add_group'),(8,'Can change group',3,'change_group'),(9,'Can delete group',3,'delete_group'),(10,'Can add user',4,'add_user'),(11,'Can change user',4,'change_user'),(12,'Can delete user',4,'delete_user'),(13,'Can add content type',5,'add_contenttype'),(14,'Can change content type',5,'change_contenttype'),(15,'Can delete content type',5,'delete_contenttype'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add resource',7,'add_resource'),(20,'Can change resource',7,'change_resource'),(21,'Can delete resource',7,'delete_resource'),(22,'Can add probability distribution',8,'add_probabilitydistribution'),(23,'Can change probability distribution',8,'change_probabilitydistribution'),(24,'Can delete probability distribution',8,'delete_probabilitydistribution'),(25,'Can add discrete probability distribution',9,'add_discreteprobabilitydistribution'),(26,'Can change discrete probability distribution',9,'change_discreteprobabilitydistribution'),(27,'Can delete discrete probability distribution',9,'delete_discreteprobabilitydistribution'),(28,'Can add continuous probability distribution',10,'add_continuousprobabilitydistribution'),(29,'Can change continuous probability distribution',10,'change_continuousprobabilitydistribution'),(30,'Can delete continuous probability distribution',10,'delete_continuousprobabilitydistribution'),(31,'Can add unit',11,'add_unit'),(32,'Can change unit',11,'change_unit'),(33,'Can delete unit',11,'delete_unit'),(34,'Can add decision variable',12,'add_decisionvariable'),(35,'Can change decision variable',12,'change_decisionvariable'),(36,'Can delete decision variable',12,'delete_decisionvariable'),(37,'Can add service',13,'add_service'),(38,'Can change service',13,'change_service'),(39,'Can delete service',13,'delete_service'),(40,'Can add service_ decision variable',14,'add_service_decisionvariable'),(41,'Can change service_ decision variable',14,'change_service_decisionvariable'),(42,'Can delete service_ decision variable',14,'delete_service_decisionvariable'),(43,'Can add provider',15,'add_provider'),(44,'Can change provider',15,'change_provider'),(45,'Can delete provider',15,'delete_provider'),(46,'Can add provider_ resource',16,'add_provider_resource'),(47,'Can change provider_ resource',16,'change_provider_resource'),(48,'Can delete provider_ resource',16,'delete_provider_resource'),(49,'Can add graphic',17,'add_graphic'),(50,'Can change graphic',17,'change_graphic'),(51,'Can delete graphic',17,'delete_graphic'),(52,'Can add axis_ graphic',18,'add_axis_graphic'),(53,'Can change axis_ graphic',18,'change_axis_graphic'),(54,'Can delete axis_ graphic',18,'delete_axis_graphic'),(55,'Can add presenter',19,'add_presenter'),(56,'Can change presenter',19,'change_presenter'),(57,'Can delete presenter',19,'delete_presenter'),(58,'Can add presenter_ graphic',20,'add_presenter_graphic'),(59,'Can change presenter_ graphic',20,'change_presenter_graphic'),(60,'Can delete presenter_ graphic',20,'delete_presenter_graphic'),(61,'Can add offering data',21,'add_offeringdata'),(62,'Can change offering data',21,'change_offeringdata'),(63,'Can delete offering data',21,'delete_offeringdata'),(64,'Can add consumer',22,'add_consumer'),(65,'Can change consumer',22,'change_consumer'),(66,'Can delete consumer',22,'delete_consumer'),(67,'Can add consumer service',23,'add_consumerservice'),(68,'Can change consumer service',23,'change_consumerservice'),(69,'Can delete consumer service',23,'delete_consumerservice'),(70,'Can add execution configuration',24,'add_executionconfiguration'),(71,'Can change execution configuration',24,'change_executionconfiguration'),(72,'Can delete execution configuration',24,'delete_executionconfiguration'),(73,'Can add execution configuration providers',25,'add_executionconfigurationproviders'),(74,'Can change execution configuration providers',25,'change_executionconfigurationproviders'),(75,'Can delete execution configuration providers',25,'delete_executionconfigurationproviders'),(76,'Can add execution group',26,'add_executiongroup'),(77,'Can change execution group',26,'change_executiongroup'),(78,'Can delete execution group',26,'delete_executiongroup'),(79,'Can add general parameters',27,'add_generalparameters'),(80,'Can change general parameters',27,'change_generalparameters'),(81,'Can delete general parameters',27,'delete_generalparameters');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-01 10:03:33
