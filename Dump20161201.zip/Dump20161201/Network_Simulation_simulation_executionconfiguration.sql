-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: Network_Simulation
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `simulation_executionconfiguration`
--

DROP TABLE IF EXISTS `simulation_executionconfiguration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `simulation_executionconfiguration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(1) NOT NULL,
  `description` longtext NOT NULL,
  `execution_group_id` int(11) NOT NULL,
  `number_consumers` int(11) NOT NULL,
  `number_periods` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `simulation_executionconfiguration_e7f3f665` (`execution_group_id`),
  CONSTRAINT `execution_group_id_refs_id_cd1bcb88` FOREIGN KEY (`execution_group_id`) REFERENCES `simulation_executiongroup` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `simulation_executionconfiguration`
--

LOCK TABLES `simulation_executionconfiguration` WRITE;
/*!40000 ALTER TABLE `simulation_executionconfiguration` DISABLE KEYS */;
INSERT INTO `simulation_executionconfiguration` VALUES (1,'I','Test the providers competition position. The idea is to understand how offers, market size, profits evolve as more providers participate in the market.\r\n\r\nOne provider. Monopoly on the market.',1,20,60),(2,'A','Test the providers competition position. The idea is to understand how offers, market size, profits evolve as more providers participate in the market.\r\n\r\nTwo providers',1,20,200),(3,'I','Test the providers competition position. The idea is to understand how offers, market size, profits evolve as more providers participate in the market.\r\n\r\nThree providers',1,20,20),(4,'I','Test the providers competition position. The idea is to understand how offers, market size, profits evolve as more providers participate in the market.\r\n\r\nFour providers',1,20,60),(5,'I','Test the providers competition position. The idea is to understand how offers, market size, profits evolve as more providers participate in the market.\r\n\r\nFive providers',1,20,40),(6,'I','Test the providers competition position. The idea is to understand how offers, market size, profits evolve as more providers participate in the market.\r\n\r\nTen providers',1,3,240);
/*!40000 ALTER TABLE `simulation_executionconfiguration` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-01 10:04:41
