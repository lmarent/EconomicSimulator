-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: Network_Simulation
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `simulation_provider`
--

DROP TABLE IF EXISTS `simulation_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `simulation_provider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `market_position` double NOT NULL,
  `adaptation_factor` double NOT NULL,
  `status` varchar(1) NOT NULL,
  `num_ancestors` int(11) NOT NULL,
  `debug` tinyint(1) NOT NULL,
  `service_id` int(11) NOT NULL,
  `monopolist_position` double NOT NULL,
  `seed` tinyint(1) NOT NULL,
  `year` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `hour` int(11) NOT NULL,
  `minute` int(11) NOT NULL,
  `second` int(11) NOT NULL,
  `microsecond` int(11) NOT NULL,
  `class_name` varchar(60) NOT NULL,
  `start_from_period` int(11) NOT NULL,
  `buying_marketplace_address` varchar(45) NOT NULL,
  `selling_marketplace_address` varchar(45) NOT NULL DEFAULT '192.168.2.12',
  `capacity_controlled_at` varchar(1) NOT NULL DEFAULT 'G',
  `purchase_service_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `simulation_provider_91a0ac17` (`service_id`),
  CONSTRAINT `service_id_refs_id_bee2a40b` FOREIGN KEY (`service_id`) REFERENCES `simulation_service` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `simulation_provider`
--

LOCK TABLES `simulation_provider` WRITE;
/*!40000 ALTER TABLE `simulation_provider` DISABLE KEYS */;
INSERT INTO `simulation_provider` VALUES (1,'Provider1 - Test EdgeProvider',0.2,0.2,'I',4,1,1,0.8,1,2014,10,5,8,33,50,578360,'ProviderEdge',1,'10.10.3.1','10.10.2.1','B',2),(2,'Provider2 - Test Transit',0.5,0.4,'I',4,1,2,0.8,1,2014,10,5,8,33,51,163518,'Provider',1,'0.0.0.0','10.10.3.1','G',NULL),(3,'Provider3 - Test EdgeMonopoly',0.2,0.2,'I',4,1,1,0.6,1,2014,10,5,8,33,51,187963,'ProviderEdgeMonopoly',1,'10.10.3.1','10.10.2.1','B',2),(4,'Provider4 - Test Transit',0.2,0.4,'I',4,1,2,0.9,1,2014,9,25,0,0,0,0,'Provider',1,'0.0.0.0','10.10.3.1','B',NULL),(5,'Provider5',0.2,0.1,'A',4,1,3,0.9,1,2014,9,1,0,0,0,0,'ProviderEdge',1,'10.10.5.2','10.10.6.2','G',4),(6,'Provider6',0.2,0.2,'A',4,1,4,0.9,1,2014,9,30,0,0,0,0,'Provider',1,'0.0.0.0','10.10.5.2','G',NULL),(7,'Provider7',0.5,0.2,'I',4,1,3,0.9,0,2014,9,30,0,0,0,0,'ProviderEdge',1,'10.10.5.2','10.10.6.2','G',4),(8,'Provider8',0.5,0.2,'A',4,1,4,0.9,0,2014,9,30,0,0,0,0,'Provider',1,'0.0.0.0','10.10.5.2','G',NULL),(9,'Provider9',0.8,0.1,'A',4,1,3,0.9,0,2014,9,30,0,0,0,0,'ProviderEdge',1,'10.10.5.2','10.10.6.2','G',4),(10,'Provider10',0.8,0.2,'A',4,1,4,0.9,0,2014,9,30,0,0,0,0,'Provider',1,'0.0.0.0','10.10.5.2','G',NULL);
/*!40000 ALTER TABLE `simulation_provider` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-01 10:05:31
