-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: Network_Simulation
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `simulation_decisionvariable`
--

DROP TABLE IF EXISTS `simulation_decisionvariable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `simulation_decisionvariable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `optimization` varchar(2) NOT NULL,
  `min_value` double NOT NULL,
  `max_value` double NOT NULL,
  `modeling` varchar(2) NOT NULL,
  `resource_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `sensitivity_distribution_id` int(11) NOT NULL,
  `value_distribution_id` int(11) NOT NULL,
  `cost_function_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `simulation_decisionvariable_217f3d22` (`resource_id`),
  KEY `simulation_decisionvariable_b9dcc52b` (`unit_id`),
  KEY `simulation_decisionvariable_bc8c2e3f` (`sensitivity_distribution_id`),
  KEY `simulation_decisionvariable_f41e8420` (`value_distribution_id`),
  KEY `cost_function_id_refs_id_2eb92cfa_idx` (`cost_function_id`),
  CONSTRAINT `cost_function_id_refs_id_2eb92cfa` FOREIGN KEY (`cost_function_id`) REFERENCES `simulation_costfunction` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `resource_id_refs_id_9eb73122` FOREIGN KEY (`resource_id`) REFERENCES `simulation_resource` (`id`),
  CONSTRAINT `sensitivity_distribution_id_refs_id_2eb92cfa` FOREIGN KEY (`sensitivity_distribution_id`) REFERENCES `simulation_probabilitydistribution` (`id`),
  CONSTRAINT `unit_id_refs_id_3e3f3956` FOREIGN KEY (`unit_id`) REFERENCES `simulation_unit` (`id`),
  CONSTRAINT `value_distribution_id_refs_id_2eb92cfa` FOREIGN KEY (`value_distribution_id`) REFERENCES `simulation_probabilitydistribution` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `simulation_decisionvariable`
--

LOCK TABLES `simulation_decisionvariable` WRITE;
/*!40000 ALTER TABLE `simulation_decisionvariable` DISABLE KEYS */;
INSERT INTO `simulation_decisionvariable` VALUES (1,'Price','L',12,20,'P',1,1,2,1,11),(2,'Delay','L',0.14,0.2,'Q',1,2,3,4,13),(3,'Bandwidth_quality','M',0,1,'Q',1,3,5,6,12),(4,'price_shared_bandwifth','L',10,18,'P',1,1,5,6,11),(5,'Delay_ISP','L',0,1,'Q',2,2,3,7,8),(6,'Price_ISP','L',0.2,1,'P',1,1,2,8,11),(7,'Delay_Transit','L',0,0.5,'Q',2,2,3,4,8),(8,'Price_Transit','L',0.1,0.9,'P',1,1,2,1,11);
/*!40000 ALTER TABLE `simulation_decisionvariable` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-01 10:04:44
